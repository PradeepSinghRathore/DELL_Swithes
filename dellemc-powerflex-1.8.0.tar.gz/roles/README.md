#dellemc.powerflex roles directory

Here are the list of roles supported.

```
.
├── powerflex_common
├── powerflex_mdm
├── powerflex_sdc
├── powerflex_lia
├── powerflex_tb
├── powerflex_sds
```