<!--
Copyright (c) 2022 Dell Inc., or its subsidiaries. All Rights Reserved.

Licensed under the GPL, Version 3.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.gnu.org/licenses/gpl-3.0.txt
-->


# Security Policy
TBD

## Reporting a Vulnerability

Have you discovered a security vulnerability in this project?
We ask you to alert the maintainers by sending an email, describing the issue, impact, and fix - if applicable.

You can reach the OpenManageAnsible Maintainers at OpenManageAnsible@dell.com