#!/bin/sh
pytest -vvvv test_diff_util.py
